#include <iostream>

using namespace std;

int main()
{

    int arr[] = {2, 3, 7, 5, 1, 0, 9, 0, 0, 0, 2};
    int size = sizeof(arr) / sizeof(arr[0]);

    int element = 3;

    int count = 0;

    for (int i = 0; i < size; i++)
    {

        if (arr[i] == element)
        {
            count++;
            // count += 1;
            // count = count +1;
        }
    }

    if (count == 2)
    {
        cout << "the given element is duplicate.";
    }
    else
    {
        cout << "the given element is not duplicate.";
    }
}