#include<iostream>
#include<vector>
using namespace std;
int main()
{

vector<int> arr;
vector<int> arr1(6);
vector<int> arr2(3,9);

// for(int i = 0;i<3;i++){
//     cout<<arr2[i]<<" ";
// }


// cout<<"Taking input in the vector :"<<endl;

// for(int i =0;i<6;i++){
//     cin>>arr1[i];
// }

// cout<<"printing the vector :"<<endl;

// for(int i =0;i<6;i++){
//     cout<<arr1[i] << " ";
// }

vector<vector<int>> mat(3,vector<int>(2));

vector<int> brr;

brr.push_back(6);
brr.push_back(60);

for(int i =0;i<2;i++){
    cout<<brr[i] << " ";
}
    
} 

