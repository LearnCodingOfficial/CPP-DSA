#include <iostream>

using namespace std;

int main()
{

    int arr[5] = {1, 2, 4, 5, 8};

    cout << "Original array : ";
    for (int i = 0; i < 5; i++)
    {

        cout << arr[i] << " ";
    }

    cout << endl;

    // int brr[4];

    // for(int i = 3;i>=0;i--){

    //     brr[4-i-1]= arr[i];
    // }

    int start = 0;
    int end = 4;

    while (end >= start)
    {

        int temp = arr[start];

        arr[start] = arr[end];
        arr[end] = temp;

        start++;
        end--;
    }

    cout << "Reversed  array : ";
    for (int i = 0; i < 5; i++)
    {

        cout << arr[i] << " ";
    }
}