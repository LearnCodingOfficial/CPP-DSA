#include <iostream>

using namespace std;

int main()
{

    int arr[] = {1, 8, 2, 5, 11, 9, 0};

    int size = sizeof(arr) / sizeof(arr[0]);

    cout << "Printing the even elements in the array : ";
    for (int i = 0; i < size; i++)
    {
        if (arr[i] % 2 == 0)
        {
            cout << arr[i] << " ";
        }
    }
    cout << endl;
    cout << "Printing the odd elements in the array : ";
    for (int i = 0; i < size; i++)
    {
        if (arr[i] % 2 != 0)
        {
            cout << arr[i] << " ";
        }
    }
}