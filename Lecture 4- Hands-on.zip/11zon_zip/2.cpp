#include<iostream>
using namespace std;
int main(){
    int arr[] = {2 ,9,1,3, 93,30};

    cout<<sizeof(arr)<<endl;
    cout<<sizeof(arr[0]);

    // int size = sizeof(arr)/sizeof(arr[1]);

    // cout << size;
}