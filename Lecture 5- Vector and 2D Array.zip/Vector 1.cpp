#include <iostream>
#include <vector>
#include<algorithm>
using namespace std;

int main()
{

    // vector<int> arr;

    // cout << arr.size() << endl;
    // cout << arr.capacity() << endl
    //      << endl;

    // arr.push_back(5);
    // cout << arr.size() << endl;
    // cout << arr.capacity() << endl
    //      << endl;

    // arr.push_back(52);
    // cout << arr.size() << endl;
    // cout << arr.capacity() << endl
    //      << endl;

    // arr.push_back(51);
    // cout << arr.size() << endl;
    // cout << arr.capacity() << endl
    //      << endl;

    // arr.push_back(65);
    // arr.push_back(15);
    // arr.push_back(50);

    // arr.push_back(68);

    // // arr.pop_back();

    // // cout<<arr.at(3);

    // cout<<arr.front()<<endl;
    // cout<<arr.back();

    // // cout<<arr.size();

    // // for(int i =0;i<arr.size();i++){

    // //     cout<<arr[i]<<" ";
    // // }
    // // cout<<endl;

    vector<int> arr;

    arr.push_back(5);
    arr.push_back(65);
    arr.push_back(15);
    arr.push_back(50);
    arr.push_back(50);
    arr.push_back(50);
    arr.push_back(50);
    arr.push_back(50);

    for (int i = 0; i < arr.size(); i++)
    {

        cout << arr[i] << " ";
    }
    cout << endl;

//     // sort(arr.rbegin(), arr.rend());

//     reverse(arr.begin(), arr.end());

//     cout << "After reverse :" << endl;
//     for (int i = 0; i < arr.size(); i++)
//     {

//         cout << arr[i] << " ";
//     }
//     cout << endl;

//  auto it = find(arr.begin(),arr.end(),500);

//  if(it != arr.end()){

//     cout<< distance(arr.begin(),it);
//  } else {
//     cout<<"Element not found";
//  }


 cout<<count(arr.begin(),arr.end(),50);

}