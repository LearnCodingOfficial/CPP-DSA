#include<iostream>
using namespace std;
int main()
{
    int arr[6]= {2 , 5, 8 , 9 ,6,4};
    
    
    int sum = 0;
    for(int i =0;i<6;i++){
        sum = sum + arr[i];
    }

    cout<< "The sum of array elements is: "<<sum <<endl;
} 
