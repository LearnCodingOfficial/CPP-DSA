#include <iostream>
using namespace std;

int main()
{

    int arr[2][3];
    arr[0][0] = 3;
    arr[0][1] = 5;
    arr[0][2] = 8;
    arr[1][0] = 30;
    arr[1][1] = 51;
    arr[1][2] = 86;


    int brr[3][2]= {{2,5},{9,1},{99,11}};



    // for(int i = 0;i<3;i++){
    //     for(int j =0;j<2;j++){
    //         cout<<brr[i][j]<<" ";
    //     }
    //     cout<<endl;
    // }

      for(int i = 0;i<2;i++){
        for(int j =0;j<3;j++){
            cout<<arr[i][j]<<" ";
        }
        cout<<endl;
    }

    return 0;
}