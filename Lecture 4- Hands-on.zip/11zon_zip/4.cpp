// #include<iostream>

// using namespace std;

// int main(){

//     int arr[]= {7,3,2,99,0,-3,8};

//     int size = sizeof(arr)/ sizeof(arr[0]);

//     int min = arr[0];

//     for(int i = 1;i<size;i++){
//         if(min > arr[i]){
//             min = arr[i];
//         }
//     }

//     cout << "The minimum element in the array is : "<<min <<endl;



//     int max = arr[0];

//     for(int i = 1; i<size;i++){
//         if(max < arr[i]){
//             max = arr[i];
//         }
//     }


//     cout<<"The maximum element in the array is : "<<max;
// }





#include<iostream>
using namespace std;

int main(){
    int arr[4] = { 1 ,2,5,3};

    int max = arr[0];
    int smax = arr[0];

    for(int i =1;i<4;i++){

        if(max < arr[i]){
            smax = max;
            max = arr[i];
        }
        // else if(smax < arr[i] && max != arr[i]){
        //     smax = arr[i];
        // }
    }

    cout<<smax;
}