#include <iostream>
using namespace std;

void print(const int arr[], int n)
{

    for (int i = 0; i < n; i++)
    {

        cout << arr[i] <<" ";
    }

    cout<<endl;

    arr[3]=68;
}
int main()
{

    int arr[5] = {2, 6, 1, 8, 0};



        print(arr,5);

        cout<<arr[3]<<endl;

         print(arr,5);





    // cout << arr[3] << endl;
    // cout << *(arr + 3);
}