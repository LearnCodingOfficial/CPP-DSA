 #include<iostream>

using namespace std;

int main(){

    int arr[]= {7,3,2,99,0,-3,88};

    int size = sizeof(arr)/ sizeof(arr[0]);

   



    int max = arr[0];
    int smax = arr[0];

    for(int i = 1; i<size;i++){
        if(max < arr[i]){
            smax = max;
            max = arr[i];
        } else if( smax < arr[i]  && arr[i] != max){
            smax =arr[i];
        }
    }


    cout<<"The maximum element in the array is : "<<max <<endl;
    cout<<"The second maximum element in the array is : "<<smax;
}

